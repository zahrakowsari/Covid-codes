clc;
clear all;
close all;
%figure(1)
%rectangle('Position',[0 0 2000 2000],'EdgeColor','r');
%rectangle('Position',[0 0 500 500],'EdgeColor','g');
%hold on;
%n is initonal pop
n=50;
x_city=40
y_city=40
x = randi([0,x_city],1,n);
y = randi([0,y_city],1,n);
duration_infecton = zeros(1,n)
%0=suspected 1=infected  2=recovered
sta = zeros(1,n)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%professional activity  
%health worker= 75.5(3%)     normal worker= 59(30%)      student= 58(22%)      inactive= 52(45%)
%awarness: high=20   Poor=60    middle=40
awarness_values = [20, 60,40]
%mobility: %constant=60   intermediate=40     restrict=20
mobility_values = [20, 40,60]
%physical health; health=25   atlethic=30  sedentary=45   comorbidity=50
physical_values = [25, 30,45,50]
activity=[]
awarness=[]
mobility=[]
age=[]
physical_health=[]

    %inactive
    for i=1:round(0.4*n)
        activity(end+1)=52
        %age
        age(end+1)=randi([65, 90], 1) || randi([1, 5], 1)
        %awarness
        a=randi([2, 3], 1)
        awarness(end+1)=awarness_values(a)
        %mobility
        mobility(end+1)=60
        %physical health
        p=randi([3, 4], 1)
        physical_health(end+1)=physical_values(p)
    end
    %normal worker
    for i=1:round(0.3*n)
        activity(end+1)=59
        %age
        age(end+1)=randi([18, 65], 1)
        %awarness
        a=randi([2, 3], 1)
        awarness(end+1)=awarness_values(a)
        %mobility
        mobility(end+1)=60
        %physical health
        p=randi([1, 2], 1)
        physical_health(end+1)=physical_values(p)
    end  
    %student
    for i=1:round(0.2*n)
        activity(end+1)=58
        %age
        age(end+1)=randi([5, 22], 1)
        %awarness
        a=randi([2, 3], 1)
        awarness(end+1)=awarness_values(a)
        %mobility
        mobility(end+1)=40
        %physical health
        p=randi([1, 2], 1)
        physical_health(end+1)=physical_values(p)
    end 
  
    %health worker 
    for i=1:round(0.1*n)
        activity(end+1)=75.5
        %age
        age(end+1)=randi([18, 65], 1)
        %awarness
        awarness(end+1)=3
        %mobility
        mobility(end+1)=60
        %physical health
        p=randi([1, 2], 1)
        physical_health(end+1)=physical_values(p)
    end  

%probibility of movement
pm = (mobility+awarness)/200
%Beta
Beta=(age+activity+mobility+awarness)/400

initial_infected = randi(n)
sta(initial_infected)=1
x_first_infected = x(initial_infected)
y_first_infected = y(initial_infected)
sta2 = sta
Trec = 10
MaxIt=25

%R is distance of getting infected
R = 2
Dis=[]
infection_in_iteration=[]
recovered_in_iteration=[]
suseptible_in_iteration=[]
for it=1:50
    clf(figure(1));
    suseptibleix=[]
    suseptibleiy=[]
    infectionx=[]
    infectiony=[]
    recoveredx=[]
    recoveredy=[]
    sta2 = sta
    %agents who getting inected
    for i = 1:length(x)
        if sta(i) == 1
            %calculating cluster of infected agent
            for j = 1:length(x)
                if sta(j)== 0
                    dis = sqrt((x(j)-x(i))^2+(y(j)-y(i))^2)
                    Dis(end+1)= dis
                    if dis < R;
                        pc=rand %the algorithm generates a probability pc as a random number [0; 1] for each non-infected agent
                        if pc < Beta(i)
                            sta2(j)=1
                        end
                
                    end
                end
            end
        end    
    end 
   
    sta = sta2
    %movement of agent
    move = randi([0,1],1,n)
    for i = 1:length(x) % start of the list
        %%%%profecional:inactive
        if activity(i) == 52
            if move(i)<= pm(i)
                place= sum(rand >= cumsum([0, 0.55, 0.2, 0.15, 0.1]))
                if place == 1
                    x(i)= randi([0,x_city])
                    y(i)= randi([x_city/2,y_city])
                end
                if place == 2
                    x(i)= randi([round(x_city/8),x_city])
                    y(i)= randi([0,y_city/2])
                end
                if place == 3
                    x(i)= randi([0,round(x_city/8)])
                    y(i)= randi([0,round(y_city/8)])
                end
                if place == 4
                    x(i)= randi([0,round(x_city/8)])
                    y(i)= randi([round(y_city/8),y_city/2])
                end
            end 
        end
        %%%%profecional:normal
        if activity(i) == 59
            if move(i)<= pm(i)
                place= sum(rand >= cumsum([0, 0.45, 0.3, 0.5, 0.2]))
                if place == 1
                    x(i)= randi([0,x_city])
                    y(i)= randi([x_city/2,y_city])
                end
                if place == 2
                    x(i)= randi([round(y_city/8),x_city])
                    y(i)= randi([0,y_city/2])
                end
                if place == 3
                    x(i)= randi([0,round(y_city/8)])
                    y(i)= randi([0,round(y_city/8)])
                end
                if place == 4
                    x(i)= randi([0,round(y_city/8)])
                    y(i)= randi([round(y_city/8),y_city/2])
                end
            end 
        end
        %%%%profecional:student
        if activity(i) == 58
            if move(i)<= pm(i)
                place= sum(rand >= cumsum([0, 0.15, 0.45, 0.5, 0.35]))
                if place == 1
                    x(i)= randi([0,x_city])
                    y(i)= randi([x_city/2,y_city])
                end
                if place == 2
                    x(i)= randi([round(y_city/8),x_city])
                    y(i)= randi([0,y_city/2])
                end
                if place == 3
                    x(i)= randi([0,round(y_city/8)])
                    y(i)= randi([0,round(y_city/8)])
                end
                if place == 4
                    x(i)= randi([0,round(y_city/8)])
                    y(i)= randi([round(y_city/8),y_city/2])
                end
            end  
        end
        %%%%profecional:health worker
        if activity(i) == 75.5
            if move(i)<= pm(i)
                place= sum(rand >= cumsum([0, 0.4, 0.1, 0.45, 0.05]))
                if place == 1
                    x(i)= randi([0,x_city])
                    y(i)= randi([x_city/2,y_city])
                end
                if place == 2
                    x(i)= randi([round(y_city/8),x_city])
                    y(i)= randi([0,y_city/2])
                end
                if place == 3
                    x(i)= randi([0,round(y_city/8)])
                    y(i)= randi([0,round(y_city/8)])
                end
                if place == 4
                    x(i)= randi([0,round(y_city/8)])
                    y(i)= randi([round(y_city/8),y_city/2])
                end
            end 
        end
   
    end
    
    
    for i = 1:length(sta) % start of the list
        if sta(i) == 0
            suseptibleix(end+1)= x(i)
            suseptibleiy(end+1)= y(i)
        end 
        if  sta(i) == 2  
             recoveredx(end+1)= x(i)
             recoveredy(end+1)= y(i)  
        end
        if  sta(i) == 1 
            infectionx(end+1)= x(i)
            infectiony(end+1)= y(i)
            duration_infecton(i)=duration_infecton(i)+1
            %Trec=randi([10 20],1)%recovery time   
            %if agent passes period of infecton it will get recovered
            if duration_infecton(i) == Trec  
                sta(i) = 2;
            end
        end
        
    end
    
    infection_in_iteration(end+1)= numel(infectionx)
    recovered_in_iteration(end+1)= numel(recoveredx)
    suseptible_in_iteration(end+1)= numel(suseptibleix)
    figure(1);
    plot(suseptibleix, suseptibleiy, 'o', 'MarkerFaceColor', 'b','MarkerEdgeColor', 'b','MarkerSize',6);
    hold on;
    plot(infectionx, infectiony, 'o', 'MarkerFaceColor', 'r','MarkerEdgeColor', 'r','MarkerSize',6);
    hold on;
    plot(recoveredx, recoveredy, 'o', 'MarkerFaceColor', 'g','MarkerEdgeColor', 'g','MarkerSize',6);
    %hospitals
    plot([0,y_city/8],[0,0],'b','LineWidth', 2)
    plot([ y_city/8 ,y_city/8],[0,y_city/8],'b','LineWidth', 2)
    plot(zeros( 1, y_city/8 ),'b','LineWidth', 2)
    plot([ 0 ,0],[0,y_city/8],'b','LineWidth', 3)
    %schools
    plot([ y_city/8 ,y_city/8],[y_city/8,y_city/2],'g','LineWidth', 2)
    plot([0,y_city/8],[y_city/8,y_city/8],'g','LineWidth', 2)
    plot(y_city/2 + zeros( 1, y_city/8 ),'g','LineWidth', 2)
    plot([ 0 ,0],[y_city/8,y_city/2],'g','LineWidth', 3)
    %circulation
    plot([0,y_city],[y_city,y_city],'m','LineWidth', 3)
    plot([0,y_city/2],[y_city/2,y_city/2],'m','LineWidth', 2)
    plot([ 0 ,0],[y_city/2,y_city],'m','LineWidth', 3)
    plot([ y_city ,y_city],[y_city/2,y_city],'m','LineWidth', 3)
    %home and industry
    plot([ y_city/8 + 0 ,y_city/8 + 0],[0,y_city/2],'r','LineWidth', 2)
    plot([ y_city/8 + 0 ,y_city],[y_city/2,y_city/2],'r','LineWidth', 2)
    plot([ y_city ,y_city],[0,y_city/2],'r','LineWidth', 3)
    plot([ y_city/8,y_city],[0,0],'r','LineWidth', 3)
    if it == 1
        saveas(figure(1),'FIG1','png');
    end
    if it == 15
        saveas(figure(1),'FIG15','png');
    end
    
    if it == 20
        saveas(figure(1),'FIG20','png');
    end
    
    if it == 50
        saveas(figure(1),'FIG50','png');
    end
    
end
xlswrite('suseptibles.xlsx',suseptible_in_iteration)
xlswrite('recovered.xlsx',recovered_in_iteration)
xlswrite('infection.xlsx',infection_in_iteration)

